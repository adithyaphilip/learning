import re
print(help(re))
