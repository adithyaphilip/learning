from ..server import ns
print(type(ns))

